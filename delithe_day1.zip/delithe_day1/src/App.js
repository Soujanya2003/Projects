import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Count from './Components/Count'
import './App.css';
import CountFunction from './Components/CountFunction';
import Timer from './Components/UseEffect';


export default function () {
  return (
    <div className='App'>
      <BrowserRouter>
        <Routes>
          <Route path="/count" element={<Count/>}></Route>
          <Route path="/countFunc" element={<CountFunction/>}></Route>
          <Route path="/timer" element={<Timer/>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}
