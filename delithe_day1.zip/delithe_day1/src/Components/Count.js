import React, { Component } from 'react'

export default class Count extends Component {
    constructor() {
        super();
        this.state = {
            count: 0,
            count2:0,
            count3:1,
            count4:10000
        }
    }
    incrementCount = () => {
        this.setState({ count: this.state.count + 1 })
    }
    decrementCount =()=>{
        this.setState({count2:this.state.count2-1})
    }

    multiplyCount=()=>{
        this.setState({count3:this.state.count3*2})
    }

    divideCount=()=>{
        this.setState({count4:this.state.count4/2})
    }

    resetCount=()=>{
        this.setState({
            count: 0,
            count2:0,
            count3:1,
            count4:10000
        })
    }
    render() {
        return (
            <div>
                <h1>{this.state.count}</h1>
                <button onClick={this.incrementCount}>INCREMENT</button>
                <br></br>
                <br></br>

                <h1>{this.state.count2}</h1>
                <button onClick={this.decrementCount}>DECREMENT</button>
                <br></br>
                <br></br>

                <h1>{this.state.count3}</h1>
                <button className='btn btn-success' onClick={this.multiplyCount}>Multiply</button>
                <br></br>
                <br></br>

                <h1>{this.state.count4}</h1>
                <button className='btn btn-danger'onClick={this.divideCount}>Divde</button>

                <br></br>
                <br></br>
                <button className='btn btn-dark' onClick={this.resetCount}>Clear</button>

                <br></br>
                <br></br>
            </div>
        )
    }
}
