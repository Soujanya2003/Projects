import React from 'react'

function FunctionalDetails(props) {
  return (
    <div>
      <h1>name:{props.name}</h1>
      <h1>age:{props.age}</h1>
      <h1>Department:{props.depart}</h1>
    </div>
  )
}

export default FunctionalDetails
